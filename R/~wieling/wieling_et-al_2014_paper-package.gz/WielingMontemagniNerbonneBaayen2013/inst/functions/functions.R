# getSD.gam will return the sd of the variation in the random intercept/slope
#
# parameters: coefs: result of coefs(model)
#             ranefFactor: the random-effect factor
#             pred: what to get sd from ("Intercept" or predictor name)
getSD.gam <- function(coefs,ranefFactor,pred) {
	coefs = data.frame(coefs)
	if (pred == "Intercept") {
		return(sd(data.frame(coefs[regexpr(paste("s(",ranefFactor,").",sep=''),rownames(coefs),fixed=T)>0,])[,1]))
	} else { 
		return(sd(data.frame(coefs[regexpr(paste("s(",ranefFactor,",",pred,").",sep=''),rownames(coefs),fixed=T)>0,])[,1]))
	}
}

# getEffectSize.gam gives a measure of effect size by investigating what the
# effect of the dependent variable is, when the predictor ranges from its 
# minimum to its maximum value
#
# parameters: dat: the data set
#             summ: the summary of the model (summary(model))
#             pred: what to get the effect size from 
getEffectSize.gam <- function(dat,summ,pred) { 
	(max(dat[,pred], na.rm=T) - min(dat[,pred], na.rm=T)) * summ$p.coef[pred]
}

# plotSlopes.gam wil plot the adjustments to the slopes of two predictors
# with respect to one random-effect factor. It will display by default
# 5 words at the outer points of the plot
#
# parameters: model: result of gam/bam
#             dataf: data set
#             ranfact: name of the random effect factor between quotes
#             pred1: name of first predictor between quotes
#             pred2: name of second predictor between quotes
#             nrWords: nr of printed words in the plots at the end points
# e.g. myCoefPlot2.gam(finalmodelC,"Word","SpEdu.z","SpIsMale")
plotSlopes.gam = function(model,dataf,ranfact,pred1,pred2,nrWords=4) { 
	
	mystr = paste('dat =',sub(".* data = (.*).", "\\1", model$call)[3])
	eval(parse(text=mystr))

	a = as.data.frame(coef(model))
	if (pred1 == "Intercept" | pred1 == "(Intercept)") { 
		splineName1 = paste("s(",ranfact,").",sep="")
	} else { 
		splineName1 = paste("s(",ranfact,",",pred1,").",sep="")
	}
	mydf = data.frame(a[regexpr(splineName1,rownames(a),fixed=T)>0,])
	colnames(mydf)[1] = pred1
	fixed1 = NA
	if (nrow(data.frame(a[regexpr(paste("^",pred1,sep=""),rownames(a),perl=T)>0,])) == 1) { 
		mydf[1] = mydf[1] + a[regexpr(paste("^",pred1,sep=""),rownames(a),perl=T)>0,] # add value of fixed effect if present
		fixed1 = a[regexpr(paste("^",pred1,sep=""),rownames(a),perl=T)>0,]
	} else if (nrow(data.frame(a[regexpr(paste("^",pred1,sep=""),rownames(a),perl=T)>0,])) > 1) {
		print("ERROR: 2 columns have the same prefix. The value is not added (pred1).")
	}
	
	if (!is.null(pred2)) { 
		if (pred2 == "Intercept" | pred2 == "(Intercept)") { 
			splineName2 = paste("s(",ranfact,").",sep="")
		} else { 
			splineName2 = paste("s(",ranfact,",",pred2,").",sep="")
		}
		col2 = data.frame(a[regexpr(splineName2,rownames(a),fixed=T)>0,])
		mydf = data.frame(mydf,col2)
		colnames(mydf)[2] = pred2
		fixed2 = NA
		if (nrow(data.frame(a[regexpr(paste("^",pred2,sep=""),rownames(a),perl=T)>0,])) == 1) { 
			mydf[2] = mydf[2] + a[regexpr(paste("^",pred2,sep=""),rownames(a),perl=T)>0,] # add value of fixed effect if present
			fixed2 = a[regexpr(paste("^",pred2,sep=""),rownames(a),perl=T)>0,]
		} else if (nrow(data.frame(a[regexpr(paste("^",pred2,sep=""),rownames(a),perl=T)>0,])) > 1) {
			print("ERROR: 2 columns have the same prefix. The value is not added (pred2).")
		}
	}

	w = mydf
	
	if (!is.null(dataf)) { 
		rownames(w) = unique(dataf[,c(ranfact)])
		rownames(w) = gsub("_"," ",rownames(w))
		rownames(w) = gsub("rotonda","rotondo",rownames(w))
	}

	w$r = rownames(w) # temporary, otherwise ordering loses column names...

	if (!is.null(pred2)) { 
		w=w[order(w[,pred2]),]
	} else { 
		w=data.frame(w[order(w[,pred1]),])
	}
	w$r = NULL

	pred1alt = pred1
	pred2alt = pred2

	w2=rbind(head(w,nrWords), tail(w,nrWords))
	

	if (!is.null(pred2)) { 
	
		plot(w[,c(pred1alt,pred2alt)], xlab="", ylab="", cex.axis=1,pch=20,type="n", xlim=c(min(w[,pred1alt])-abs(min(w[,pred1alt]))*0.5, max(w[,pred1alt])+abs(max(w[,pred1alt]))*0.5))

		if (!is.na(fixed1)) { 
			if (fixed1 < 0) { 
				xmin = par()$usr[1]
				xmax = 0 
			} else { 
				xmin = 0 
				xmax = par()$usr[2]
			}
			vline = fixed1
		}
		else { 
			xmin = 0 
			xmax = par()$usr[2]
			vline = 0
		}

		if (!is.na(fixed2)) { 
			if (fixed2 < 0) { 
				ymin = par()$usr[3]
				ymax = 0 
			} else { 
				ymin = 0 
				ymax = par()$usr[4]
			}
			hline = fixed2
		}
		else { 
			ymin = 0 
			ymax = par()$usr[4]
			hline = 0
		}
		
		points(w[,c(pred1alt,pred2alt)], xlab="", ylab="", cex.axis=1.4,pch=20,xlim=c(min(w[,pred1alt])-abs(min(w[,pred1alt]))*0.2, max(w[,pred1alt])+abs(max(w[,pred1alt]))*0.2))
		
		abline(v=vline,h=hline,lty=2)
		abline(v=0,h=0,lty=1)

		for (i in 1:length(w[,pred1alt])) { 
			if (i <= nrWords | i > length(w[,pred1alt])-nrWords) { 
				if (i > 0.5*length(w[,pred1alt])) { text(x=w[,pred1alt][i],y=w[,pred2alt][i], rownames(w)[i], pos=2,cex=1)}
				else { text(w[,pred1alt][i],y=w[,pred2alt][i], rownames(w)[i], pos=4,cex=1)}
			}
		}

		box()
		title(xlab=paste("Coefficient",pred1), ylab=paste("Coefficient",pred2),cex.lab=1.5)
	}
	else { 
		rownames(w) = gsub("\\*.*","",rownames(w))
		plot(w[,pred1alt],xlab="",ylab="",xaxt='n',ann=F,xlim=c(0,length(w[,pred1alt])))

		if (!is.na(fixed1)) { 
			abline(h=fixed1,lty=2)
		}
		abline(h=0,lty=1)

		for (i in 1:length(w[,pred1alt])) { 
			if (i <= nrWords | i > length(w[,pred1alt])-nrWords) { 
				add = 0
				
				if (i > 0.5*length(w[,pred1alt])) {
					poss = 2
				} else { 
					poss = 4
				}
				text(x=i,y=w[,pred1alt][i], rownames(w)[i], pos=poss,cex=1)
			}
		}
		title(xlab="Sorted index",ylab=paste("Coefficient",pred1),cex.lab=1.5)
	}
}


# plotSlope.gam wil plot the adjustments to the slope of one predictor
# with respect to one random-effect factor. It will display by default
# 5 words at the outer points of the plot
#
# parameters: model: result of gam/bam
#             dataf: data set
#             ranfact: name of the random effect factor between quotes
#             pred1: name of predictor between quotes
#             nrWords: nr of printed words in the plots at the end points
plotSlope.gam = function(model,dataf,ranfact,pred1,nrWords=4,labelcolumn=NULL) { 
	plotSlopes.gam(model,dataf,ranfact,pred1,NULL,nrWords)
}

